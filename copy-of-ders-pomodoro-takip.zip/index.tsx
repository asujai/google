
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

// Declare Chart.js globally
declare var Chart: any;

// Defines the structure for main tasks and their associated sub-tasks
interface SubTasksByMainTaskDefinition {
  [mainTask: string]: string[];
}

let subTasksByMainTaskDefinition: SubTasksByMainTaskDefinition = {
  Matematik: ['Problemler', 'Geometri', 'Fonksiyonlar', 'Limit', 'Türev'],
  Fizik: ['Kuvvet', 'Hareket', 'Elektrik', 'Optik'],
  Kimya: ['Atom', 'Periyodik Sistem', 'Kimyasal Tepkimeler'],
  Biyoloji: ['Hücre', 'Canlılar Alemi', 'Ekoloji'],
  Tarih: ['İnkılaplar', 'Osmanlı', 'Çağdaş Dünya']
};

interface StudyRecord {
  mainTask: string;
  subTask: string;
  seconds: number;
  date: string;
  pauseCount: number; 
  distractionCount: number;
}
let studyRecords: StudyRecord[] = [];

interface PomodoroGoalDetail {
    weeklyGoal: number;
    monthlyGoal: number;
}
interface PomodoroGoals {
    [mainTask: string]: PomodoroGoalDetail;
}
let goals: PomodoroGoals = {};

let selectedMainTask: string = '';
let selectedSubTask: string = '';

let pomodoroTimerId: number | null = null; // Renamed from timer
let timeLeft: number = 25 * 60;
// let isRunning: boolean = false; // Replaced by pomodoroState
let currentStart: number | null = null; 
let currentPauseCount: number = 0; 
let currentDistractionCount: number = 0;

// Pomodoro and Sound Settings
let pomodoroDuration: number = 25;
let selectedTheme: string = 'black'; // Default theme set to black
let soundEnabled: boolean = true;
let selectedSound: string = 'default'; 

// Break Management Settings & State
let shortBreakDurationMinutes: number = 5;
let longBreakDurationMinutes: number = 15;
let pomodorosPerLongBreak: number = 4;
let pomodoroCycleCounter: number = 0; // Tracks completed Pomodoros for long break
type PomodoroStateType = 'idle' | 'running' | 'paused' | 'break_proposed' | 'break_running';
let pomodoroState: PomodoroStateType = 'idle';
let currentBreakType: 'short' | 'long' | null = null;
let breakTimeLeftSeconds: number = 0;
let breakTimerId: number | null = null;


// HTML element references
const mainTaskSelect = document.getElementById('mainTask') as HTMLSelectElement;
const subTaskSelect = document.getElementById('subTask') as HTMLSelectElement;
const editSubTasksBtn = document.getElementById('edit-sub-tasks-btn') as HTMLButtonElement;
const timerLabel = document.getElementById('timer-label') as HTMLElement;
const startBtn = document.getElementById('start-btn') as HTMLButtonElement;
const pauseBtn = document.getElementById('pause-btn') as HTMLButtonElement;
const distractionBtn = document.getElementById('distraction-btn') as HTMLButtonElement;
const resetBtn = document.getElementById('reset-btn') as HTMLButtonElement;
const reportBtn = document.getElementById('report-btn') as HTMLButtonElement;
const reportModal = document.getElementById('report-modal') as HTMLElement;
const reportContent = document.getElementById('report-content') as HTMLElement;
const closeModalBtn = reportModal.querySelector('.close') as HTMLButtonElement;

const settingsBtn = document.getElementById('settings-btn') as HTMLButtonElement;
const settingsModal = document.getElementById('settings-modal') as HTMLElement;
const pomodoroInput = document.getElementById('pomodoro-duration') as HTMLInputElement;
const themeSelect = document.getElementById('theme-select') as HTMLSelectElement;
const soundCheckbox = document.getElementById('sound-enabled') as HTMLInputElement;
const soundSelect = document.getElementById('sound-select') as HTMLSelectElement;
const saveSettingsBtn = document.getElementById('save-settings') as HTMLButtonElement;

// Break Settings Inputs
const shortBreakDurationInput = document.getElementById('short-break-duration') as HTMLInputElement;
const longBreakDurationInput = document.getElementById('long-break-duration') as HTMLInputElement;
const pomodorosPerLongBreakInput = document.getElementById('pomodoros-per-long-break') as HTMLInputElement;

const mainTaskListContainer = document.getElementById('main-task-list-container') as HTMLElement;
const newMainTaskInput = document.getElementById('new-main-task-input') as HTMLInputElement;
const addMainTaskBtn = document.getElementById('add-main-task-btn') as HTMLButtonElement;

const goalsSettingsBtn = document.getElementById('goals-settings-btn') as HTMLButtonElement;
const goalsModal = document.getElementById('goals-modal') as HTMLElement;
const goalsFormContainer = document.getElementById('goals-form-container') as HTMLElement;
const saveGoalsBtn = document.getElementById('save-goals-btn') as HTMLButtonElement;
const closeGoalsModalBtn = goalsModal.querySelector('.close-goals') as HTMLButtonElement;

const editSubTasksModal = document.getElementById('edit-sub-tasks-modal') as HTMLElement;
const editSubTasksModalTitle = document.getElementById('edit-sub-tasks-title') as HTMLElement;
const currentSubTaskListContainer = document.getElementById('current-sub-task-list-container') as HTMLElement;
const newSubTaskNameModalInput = document.getElementById('new-sub-task-name-modal') as HTMLInputElement;
const addSubTaskModalBtn = document.getElementById('add-sub-task-modal-btn') as HTMLButtonElement;
const closeEditSubTasksModalBtn = editSubTasksModal.querySelector('.close-edit-sub-tasks-modal') as HTMLButtonElement;

const timerFocusArea = document.getElementById('timer-focus-area') as HTMLElement;
const fullscreenBtn = document.getElementById('fullscreen-btn') as HTMLButtonElement;
const finishNowBtn = document.getElementById('finish-now-btn') as HTMLButtonElement;

// Break Control Buttons & Message Div
const breakMessageDiv = document.getElementById('breakMessageDiv') as HTMLElement;
const startBreakBtn = document.getElementById('startBreakBtn') as HTMLButtonElement;
const skipBreakBtn = document.getElementById('skipBreakBtn') as HTMLButtonElement;
const endBreakBtn = document.getElementById('endBreakBtn') as HTMLButtonElement;


// AI Chat Elements
const aiChatContainer = document.getElementById('ai-chat-container') as HTMLElement;
const chatMessagesDiv = document.getElementById('chat-messages') as HTMLElement;
const chatInput = document.getElementById('chat-input') as HTMLTextAreaElement;
const sendChatBtn = document.getElementById('send-chat-btn') as HTMLButtonElement;
const chatLoading = document.getElementById('chat-loading') as HTMLElement;
const apiKeyMissingDiv = document.getElementById('api-key-missing-message') as HTMLElement;
const chartsWrapper = document.querySelector('.charts-wrapper') as HTMLElement;

// Productivity Update Elements
const productivityUpdateContent = document.getElementById('productivity-update-content') as HTMLElement;
const productivityUpdateLoading = document.getElementById('productivity-update-loading') as HTMLElement;


const mainTaskShortNameMappings: { [key: string]: string } = {
  Matematik: 'MAT', Fizik: 'FZK', Kimya: 'KMY', Biyoloji: 'BYL', Tarih: 'TRH'
};
const subTaskShortNameMappings: { [key: string]: string } = {
  Problemler: 'PRB', Geometri: 'GEO', Fonksiyonlar: 'FNK', Limit: 'LMT', Türev: 'TRV',
  Kuvvet: 'KVT', Hareket: 'HRK', Elektrik: 'ELK', Optik: 'OPT',
  Atom: 'ATM', 'Periyodik Sistem': 'PRS', 'Kimyasal Tepkimeler': 'KTP',
  Hücre: 'HCR', 'Canlılar Alemi': 'CLA', Ekoloji: 'EKL',
  İnkılaplar: 'INK', Osmanlı: 'OSM', 'Çağdaş Dünya': 'CDA'
};

// AI Chat variables
let ai: GoogleGenAI | null = null;
let chatHistory: { role: 'user' | 'model' | 'error', text: string }[] = [];
let isAIChatLoading: boolean = false;
const apiKey: string | undefined = process.env.API_KEY;


function populateMainTaskDropdown() {
    const previousMainTask = mainTaskSelect.value;
    mainTaskSelect.innerHTML = '<option value="">Ana İş seçiniz</option>';
    const taskNames = Object.keys(subTasksByMainTaskDefinition);
    taskNames.forEach(taskName => {
        const opt = document.createElement('option');
        opt.value = taskName;
        opt.textContent = taskName;
        mainTaskSelect.appendChild(opt);
    });
    if (taskNames.includes(previousMainTask)) {
        mainTaskSelect.value = previousMainTask;
    } else {
        selectedMainTask = '';
        selectedSubTask = '';
        editSubTasksBtn.style.display = 'none';
    }
    if (mainTaskSelect.value && taskNames.includes(mainTaskSelect.value)) {
         mainTaskSelect.dispatchEvent(new Event('change'));
    } else {
        populateSubTaskDropdown();
        editSubTasksBtn.style.display = 'none';
    }
}

function populateSubTaskDropdown() {
    const previousSubTask = subTaskSelect.value;
    subTaskSelect.innerHTML = '<option value="">Alt İş seçiniz</option>';
    if (selectedMainTask && subTasksByMainTaskDefinition[selectedMainTask]) {
        subTasksByMainTaskDefinition[selectedMainTask].forEach(subTask => {
            const opt = document.createElement('option');
            opt.value = subTask;
            opt.textContent = subTask;
            subTaskSelect.appendChild(opt);
        });
        editSubTasksBtn.style.display = selectedMainTask && subTasksByMainTaskDefinition[selectedMainTask] ? 'inline-block' : 'none';

        if (subTasksByMainTaskDefinition[selectedMainTask].includes(previousSubTask)) {
            subTaskSelect.value = previousSubTask;
        } else {
            selectedSubTask = '';
        }
    } else {
        editSubTasksBtn.style.display = 'none';
        selectedSubTask = '';
    }
}

mainTaskSelect.addEventListener('change', () => {
  selectedMainTask = mainTaskSelect.value;
  populateSubTaskDropdown();
  selectedSubTask = ''; 
  subTaskSelect.value = ''; 
  editSubTasksBtn.style.display = selectedMainTask ? 'inline-block' : 'none';
});

subTaskSelect.addEventListener('change', () => {
  selectedSubTask = subTaskSelect.value;
});

function formatTime(sec: number): string {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

function updateTimerLabel() {
  if (pomodoroState === 'break_running' || pomodoroState === 'break_proposed') {
    timerLabel.textContent = formatTime(breakTimeLeftSeconds);
  } else {
    timerLabel.textContent = formatTime(timeLeft);
  }
  
  let titleTime = pomodoroState === 'break_running' ? formatTime(breakTimeLeftSeconds) : formatTime(timeLeft);
  let titleSuffix = "Ana İş Pomodoro";
  if (pomodoroState === 'paused') titleSuffix = "Ana İş Pomodoro (Duraklatıldı)";
  else if (pomodoroState === 'break_proposed' || pomodoroState === 'break_running') titleSuffix = `${currentBreakType === 'short' ? 'Kısa' : 'Uzun'} Mola`;
  
  document.title = `${titleTime} - ${titleSuffix}`;
}

function updateButtonVisibilityAndState() {
    // Hide all buttons initially, then show based on state
    startBtn.style.display = 'none';
    pauseBtn.style.display = 'none';
    resetBtn.style.display = 'none';
    finishNowBtn.style.display = 'none';
    fullscreenBtn.style.display = 'none';
    distractionBtn.style.display = 'none';
    startBreakBtn.style.display = 'none';
    skipBreakBtn.style.display = 'none';
    endBreakBtn.style.display = 'none';
    breakMessageDiv.textContent = '';
    breakMessageDiv.style.display = 'none';

    switch (pomodoroState) {
        case 'idle':
            startBtn.textContent = 'Başlat';
            startBtn.style.display = 'inline-block';
            resetBtn.style.display = (timeLeft !== pomodoroDuration * 60) ? 'inline-block' : 'none'; // Show reset if not full
            updateTimerLabel();
            break;
        case 'running':
            pauseBtn.style.display = 'inline-block';
            distractionBtn.style.display = 'inline-block';
            resetBtn.style.display = 'inline-block';
            finishNowBtn.style.display = 'inline-block';
            fullscreenBtn.style.display = 'inline-block';
            updateTimerLabel();
            break;
        case 'paused':
            startBtn.textContent = 'Devam Et';
            startBtn.style.display = 'inline-block';
            resetBtn.style.display = 'inline-block';
            finishNowBtn.style.display = 'inline-block'; // Can still finish if paused
            // fullscreenBtn.style.display = 'inline-block'; // Optional: show fullscreen when paused
            updateTimerLabel();
            break;
        case 'break_proposed':
            startBreakBtn.style.display = 'inline-block';
            skipBreakBtn.style.display = 'inline-block';
            breakMessageDiv.textContent = `${currentBreakType === 'short' ? 'Kısa' : 'Uzun'} Mola Zamanı! (${formatTime(breakTimeLeftSeconds)})`;
            breakMessageDiv.style.display = 'block';
            timerLabel.textContent = formatTime(breakTimeLeftSeconds); // Show break time on main label
            document.title = `${formatTime(breakTimeLeftSeconds)} - Mola Önerisi`;
            break;
        case 'break_running':
            endBreakBtn.style.display = 'inline-block';
            fullscreenBtn.style.display = 'inline-block'; // Allow fullscreen during breaks
            breakMessageDiv.textContent = `Devam Eden ${currentBreakType === 'short' ? 'Kısa' : 'Uzun'} Mola`;
            breakMessageDiv.style.display = 'block';
            updateTimerLabel(); // Will show breakTimeLeftSeconds
            break;
    }
    // Ensure fullscreen button text is correct if visible and in fullscreen
    if (fullscreenBtn.style.display !== 'none' && document.fullscreenElement) {
        fullscreenBtn.textContent = 'Çıkış';
    } else if (fullscreenBtn.style.display !== 'none') {
        fullscreenBtn.textContent = 'Tam Ekran';
    }
}


function handlePomodoroCompletion() {
    if(pomodoroTimerId) clearInterval(pomodoroTimerId);
    pomodoroTimerId = null;
    
    addStudyTime(selectedMainTask, selectedSubTask, pomodoroDuration * 60, currentPauseCount, currentDistractionCount);
    currentPauseCount = 0; 
    currentDistractionCount = 0;
    
    pomodoroCycleCounter++;
    if (pomodoroCycleCounter >= pomodorosPerLongBreak) {
        currentBreakType = 'long';
        breakTimeLeftSeconds = longBreakDurationMinutes * 60;
        pomodoroCycleCounter = 0; 
    } else {
        currentBreakType = 'short';
        breakTimeLeftSeconds = shortBreakDurationMinutes * 60;
    }
    saveSettingsToLocalStorage(); // Save cycle counter

    if (soundEnabled) playBeep(); 
    // alert('Süre doldu! Şimdi mola zamanı.'); // Replaced by UI proposal

    pomodoroState = 'break_proposed';
    timeLeft = pomodoroDuration * 60; // Reset pomodoro time for next session
    
    if (document.fullscreenElement) {
        document.exitFullscreen().catch(e => console.error("Error exiting fullscreen on completion:", e));
    }
    updateButtonVisibilityAndState();
}

startBtn.addEventListener('click', () => {
  if (!selectedMainTask || !selectedSubTask) {
    alert('Lütfen önce Ana İş ve Alt İş seçin!');
    return;
  }

  if (pomodoroState === 'idle' || pomodoroState === 'paused') {
    if (pomodoroState === 'idle' || timeLeft === pomodoroDuration * 60 || timeLeft <=0 || timeLeft > pomodoroDuration * 60) { // New or fully reset session
        timeLeft = pomodoroDuration * 60;
        currentPauseCount = 0; 
        currentDistractionCount = 0;
    }
    // If resuming from pause, timeLeft and currentPauseCount are already set.
    
    currentStart = Date.now(); 
    pomodoroState = 'running';

    updateTimerLabel(); 
    pomodoroTimerId = window.setInterval(() => {
      timeLeft--;
      updateTimerLabel();
      if (timeLeft <= 0) {
        handlePomodoroCompletion();
      }
    }, 1000);
  }
  updateButtonVisibilityAndState();
});

pauseBtn.addEventListener('click', () => {
  if (pomodoroState === 'running') { 
    pomodoroState = 'paused';
    if(pomodoroTimerId) clearInterval(pomodoroTimerId);
    pomodoroTimerId = null;
    currentPauseCount++; 
  }
  updateButtonVisibilityAndState();
});

distractionBtn.addEventListener('click', () => {
    if (pomodoroState === 'running') {
        currentDistractionCount++;
        // Optional: Visual feedback
        distractionBtn.classList.add('active-pulse');
        setTimeout(() => {
            distractionBtn.classList.remove('active-pulse');
        }, 300);
        // console.log("Distraction recorded. Total distractions for this session:", currentDistractionCount);
    }
});

resetBtn.addEventListener('click', () => {
  if(pomodoroTimerId) clearInterval(pomodoroTimerId);
  pomodoroTimerId = null;
  if(breakTimerId) clearInterval(breakTimerId);
  breakTimerId = null;

  timeLeft = pomodoroDuration * 60;
  currentPauseCount = 0; 
  currentDistractionCount = 0;
  pomodoroCycleCounter = 0; // Reset cycle counter on manual reset
  currentBreakType = null;
  breakTimeLeftSeconds = 0;
  saveSettingsToLocalStorage(); // Save reset cycle counter
  
  pomodoroState = 'idle';
  if (document.fullscreenElement) {
      document.exitFullscreen().catch(e => console.error("Error exiting fullscreen on reset:", e));
  }
  updateButtonVisibilityAndState();
});

// --- Break Management Functions ---
startBreakBtn.addEventListener('click', () => {
    if (pomodoroState === 'break_proposed') {
        pomodoroState = 'break_running';
        // breakTimeLeftSeconds is already set
        
        breakTimerId = window.setInterval(() => {
            breakTimeLeftSeconds--;
            updateTimerLabel(); // Will display break time
            if (breakTimeLeftSeconds <= 0) {
                handleBreakCompletion();
            }
        }, 1000);
        updateButtonVisibilityAndState();
    }
});

skipBreakBtn.addEventListener('click', () => {
    if (pomodoroState === 'break_proposed') {
        if(breakTimerId) clearInterval(breakTimerId); // Should not be running, but as a safeguard
        breakTimerId = null;
        currentBreakType = null;
        breakTimeLeftSeconds = 0;
        pomodoroState = 'idle'; // Go to idle, ready for next Pomodoro
        timeLeft = pomodoroDuration * 60; // Ensure Pomodoro timer is reset
        updateButtonVisibilityAndState();
    }
});

endBreakBtn.addEventListener('click', () => { // Ends break early
    if (pomodoroState === 'break_running') {
        handleBreakCompletion(true); // Pass true to indicate early end
    }
});

function handleBreakCompletion(endedEarly: boolean = false) {
    if(breakTimerId) clearInterval(breakTimerId);
    breakTimerId = null;
    
    if (soundEnabled) playBeep(endedEarly ? 'short_pulse' : 'low_pitch'); // Different sound for early end
    if (!endedEarly) alert('Mola bitti! Çalışmaya geri dön.');
    else alert('Mola erken bitirildi.');

    currentBreakType = null;
    breakTimeLeftSeconds = 0;
    pomodoroState = 'idle';
    timeLeft = pomodoroDuration * 60; // Reset Pomodoro time for next session
    
    if (document.fullscreenElement) { // Exit fullscreen if break was in fullscreen
        document.exitFullscreen().catch(e => console.error("Error exiting fullscreen on break completion:", e));
    }
    updateButtonVisibilityAndState();
}


function addStudyTime(mainTask: string, subTask: string, seconds: number, pauses: number, distractions: number) {
  if (!mainTask || !subTask || seconds <=0) return; 
  const now = new Date();
  studyRecords.push({ mainTask, subTask, seconds, date: now.toISOString(), pauseCount: pauses, distractionCount: distractions });
  saveRecordsToLocalStorage();
}

reportBtn.addEventListener('click', () => {
  showReport('day');
  reportModal.style.display = 'block';
  reportModal.setAttribute('aria-hidden', 'false');
  const firstFilterButton = document.querySelector('.filter-btn[data-range="day"]') as HTMLButtonElement | null;
  if (firstFilterButton) firstFilterButton.focus();
});

const filterBtns = document.querySelectorAll('.filter-btn');
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    showReport((btn as HTMLElement).dataset.range as ReportRange);
  });
});

let barChart: any, pieChart: any, lineChart: any;
const chartColors: string[] = [
  '#1976d2', '#e53935', '#ffb300', '#43a047', '#8e24aa', '#00838f', '#f4511e', '#3949ab', '#c0ca33', '#6d4c41', '#d81b60', '#00acc1', '#fbc02d', '#5e35b1', '#039be5', '#7cb342', '#fb8c00', '#546e7a'
];

const getChartFontColor = (): string => document.body.classList.contains('theme-black') ? '#e0e0e0' : '#333';

function updateChartFontColors() {
    const fontColor = getChartFontColor();
    if (typeof Chart !== 'undefined' && Chart.defaults) {
        Chart.defaults.color = fontColor;
    }

    [barChart, pieChart, lineChart].forEach(chart => {
        if (chart && chart.options) {
            if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
                 chart.options.plugins.legend.labels.color = fontColor;
            }
            if (chart.options.scales) {
                if (chart.options.scales.x && chart.options.scales.x.ticks) {
                    chart.options.scales.x.ticks.color = fontColor;
                }
                if (chart.options.scales.y && chart.options.scales.y.ticks) {
                    chart.options.scales.y.ticks.color = fontColor;
                }
                 if (chart.options.scales.x && chart.options.scales.x.title && chart.options.scales.x.title.display) {
                    chart.options.scales.x.title.color = fontColor;
                }
                if (chart.options.scales.y && chart.options.scales.y.title && chart.options.scales.y.title.display) {
                    chart.options.scales.y.title.color = fontColor;
                }
            }
            chart.update();
        }
    });
}

type ReportRange = 'day' | 'week' | 'month' | 'goals' | 'ai-chat' | 'productivity-update' | 'pause-analysis' | 'distraction-analysis';

function showReport(range: ReportRange) {
  reportContent.innerHTML = ''; 
  reportContent.style.display = 'none';
  chartsWrapper.style.display = 'none';
  aiChatContainer.style.display = 'none';
  productivityUpdateContent.style.display = 'none';
  if(productivityUpdateLoading) productivityUpdateLoading.style.display = 'none';


  const barCanvas = document.getElementById('bar-chart') as HTMLCanvasElement | null;
  const pieCanvas = document.getElementById('pie-chart') as HTMLCanvasElement | null;
  const lineCanvas = document.getElementById('line-chart') as HTMLCanvasElement | null;

  if (!barCanvas || !pieCanvas || !lineCanvas) return;

  if (range === 'goals') {
    displayGoalProgressReport();
    return;
  }
  if (range === 'ai-chat') {
    displayAIChatInterface();
    return;
  }
  if (range === 'productivity-update') {
    fetchAndDisplayProductivityUpdate();
    return;
  }
  if (range === 'pause-analysis') {
    displayPauseAnalysisReport();
    return;
  }
  if (range === 'distraction-analysis') {
    displayDistractionAnalysisReport();
    return;
  }


  reportContent.style.display = 'block';
  chartsWrapper.style.display = 'flex';
  barCanvas.style.display = 'none'; 
  pieCanvas.style.display = 'none';
  lineCanvas.style.display = 'none';


  const now = new Date();
  let startOfRange: Date;
  if (range === 'day') {
    startOfRange = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  } else if (range === 'week') {
    const dayOfWeek = now.getDay() || 7; 
    startOfRange = new Date(now.getFullYear(), now.getMonth(), now.getDate() - dayOfWeek + 1);
  } else if (range === 'month') {
    startOfRange = new Date(now.getFullYear(), now.getMonth(), 1);
  } else {
    reportContent.innerHTML = '<p>Geçersiz rapor aralığı.</p>';
    return;
  }
  const filtered = studyRecords.filter(r => new Date(r.date) >= startOfRange);

  if (filtered.length === 0) {
    reportContent.innerHTML = '<p>Seçilen zaman aralığı için henüz çalışma kaydı bulunmamaktadır.</p>';
    chartsWrapper.style.display = 'none'; 
    return;
  }

  const fontColor = getChartFontColor();

  if (range === 'day' || range === 'month') {
    barCanvas.style.display = '';
    pieCanvas.style.display = '';

    const summary: { [key: string]: number } = {};
    filtered.forEach(r => {
      const mtKey = mainTaskShortNameMappings[r.mainTask] || r.mainTask;
      const stKey = subTaskShortNameMappings[r.subTask] || r.subTask;
      const combinedKey = `${mtKey} - ${stKey}`;
      if (!summary[combinedKey]) summary[combinedKey] = 0;
      summary[combinedKey] += r.seconds;
    });

    let html = '<table class="stat-table"><thead><tr><th>Ana İş - Alt İş</th><th>Süre (dk)</th></tr></thead><tbody>';
    const sortedSummaryKeys = Object.keys(summary).sort((a,b) => summary[b] - summary[a]); 

    for (const key of sortedSummaryKeys) {
      html += `<tr><td>${key}</td><td>${Math.round(summary[key]/60)}</td></tr>`;
    }
    html += '</tbody></table>';
    reportContent.innerHTML = html;
    drawBarAndPieCharts(summary, fontColor, barCanvas, pieCanvas);

  } else if (range === 'week') {
    lineCanvas.style.display = '';
    const days = ['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'];
    let weekDataByDay: { [key: string]: number }[] = Array(7).fill(null).map(() => ({}));

    filtered.forEach(r => {
        const recordDate = new Date(r.date);
        let dayIndex = recordDate.getDay() -1; 
        if (dayIndex === -1) dayIndex = 6; 

        if (dayIndex >=0 && dayIndex < 7) {
            const mtKey = mainTaskShortNameMappings[r.mainTask] || r.mainTask;
            const stKey = subTaskShortNameMappings[r.subTask] || r.subTask;
            const combinedKey = `${mtKey} - ${stKey}`;
            if (!weekDataByDay[dayIndex][combinedKey]) weekDataByDay[dayIndex][combinedKey] = 0;
            weekDataByDay[dayIndex][combinedKey] += r.seconds;
        }
    });

    let html = '<table class="stat-table"><thead><tr><th>Ana İş - Alt İş</th>';
    days.forEach(day => html += `<th>${day} (dk)</th>`);
    html += '</tr></thead><tbody>';

    const allCombinedKeys = new Set<string>();
    filtered.forEach(r => {
        const mtKey = mainTaskShortNameMappings[r.mainTask] || r.mainTask;
        const stKey = subTaskShortNameMappings[r.subTask] || r.subTask;
        allCombinedKeys.add(`${mtKey} - ${stKey}`);
    });
    const sortedCombinedKeys = Array.from(allCombinedKeys).sort();


    sortedCombinedKeys.forEach(key => {
        html += `<tr><td>${key}</td>`;
        for(let i=0; i<7; i++) {
            const totalSeconds = weekDataByDay[i][key] || 0;
            html += `<td>${totalSeconds ? Math.round(totalSeconds/60) : ''}</td>`;
        }
        html += '</tr>';
    });
    html += '</tbody></table>';
    reportContent.innerHTML = html;
    drawLineChart(filtered, startOfRange, fontColor, lineCanvas);
  }
}

function drawBarAndPieCharts(summary: { [key: string]: number }, fontColor: string, barCanvas: HTMLCanvasElement, pieCanvas: HTMLCanvasElement) {
   const labels = Object.keys(summary);
   const data = Object.values(summary).map(s => Math.round(s/60));

   const pieDataAggregated: { [key: string]: number } = {};
   labels.forEach((label, index) => {
       const mainTaskPart = label.split(' - ')[0];
       let originalMainTaskName = Object.keys(mainTaskShortNameMappings).find(key => mainTaskShortNameMappings[key] === mainTaskPart);
       if (!originalMainTaskName) {
            const directMatch = Object.keys(subTasksByMainTaskDefinition).find(mt => mt === mainTaskPart);
            originalMainTaskName = directMatch || mainTaskPart; 
       }

       if (!pieDataAggregated[originalMainTaskName]) pieDataAggregated[originalMainTaskName] = 0;
       pieDataAggregated[originalMainTaskName] += data[index];
   });
   const pieLabels = Object.keys(pieDataAggregated);
   const pieDataValues = Object.values(pieDataAggregated);

   if (barChart) barChart.destroy();
   const barCtx = barCanvas.getContext('2d');
   if (!barCtx) return;
   barChart = new Chart(barCtx, {
     type: 'bar',
     data: { labels, datasets: [{ label: 'Süre (dk)', data, backgroundColor: labels.map((_,i)=>chartColors[i%chartColors.length]), }] },
     options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { ticks: { color: fontColor, font: {weight:'bold'} } }, y: { beginAtZero: true, ticks: { color: fontColor }, title: { display: true, text: 'Süre (dk)', color: fontColor } } } }
   });
   if (pieChart) pieChart.destroy();
   const pieCtx = pieCanvas.getContext('2d');
   if (!pieCtx) return;
   pieChart = new Chart(pieCtx, {
     type: 'pie', data: { labels: pieLabels, datasets: [{ data: pieDataValues, backgroundColor: pieLabels.map((_,i)=>chartColors[i%chartColors.length]), }] },
     options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', labels: {color:fontColor} }, tooltip: { enabled: true } } }
   });
}

function drawLineChart(filteredRecords: StudyRecord[], weekStartDate: Date, fontColor: string, lineCanvas: HTMLCanvasElement) {
  const days = ['Pzt','Sal','Çar','Per','Cum','Cmt','Paz'];
  let weekTotals = Array(7).fill(0);
  filteredRecords.forEach(r => {
    const recordDate = new Date(r.date);
    let dayIndex = recordDate.getDay() - 1;
    if (dayIndex === -1) dayIndex = 6; 

    if (dayIndex >= 0 && dayIndex < 7) weekTotals[dayIndex] += r.seconds;
  });

  if (lineChart) lineChart.destroy();
  const lineCtx = lineCanvas.getContext('2d');
  if(!lineCtx) return;
  lineChart = new Chart(lineCtx, {
    type: 'line', data: { labels: days, datasets: [{ label: 'Toplam Süre (dk)', data: weekTotals.map(s=>Math.round(s/60)), borderColor: '#1976d2', backgroundColor: 'rgba(25,118,210,0.15)', tension: 0.3, pointBackgroundColor: days.map((_,i)=>chartColors[i%chartColors.length]), pointRadius: 6, }] },
    options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { display: false }, tooltip: { enabled: true } }, scales: { x: { ticks: { color: fontColor, font: {weight:'bold'} } }, y: { beginAtZero: true, ticks: { color: fontColor }, title: { display: true, text: 'Toplam Süre (dk)', color: fontColor } } } }
  });
}

function displayPauseAnalysisReport() {
    reportContent.innerHTML = '';
    chartsWrapper.style.display = 'none';
    aiChatContainer.style.display = 'none';
    productivityUpdateContent.style.display = 'none';
    if(productivityUpdateLoading) productivityUpdateLoading.style.display = 'none';

    const pauseSummary: { [combinedKey: string]: { dailyPauses: number; weeklyPauses: number } } = {};
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()); 

    const currentDayOfWeek = now.getDay(); 
    const diffToMonday = currentDayOfWeek === 0 ? -6 : 1 - currentDayOfWeek; 
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMonday);
    startOfWeek.setHours(0, 0, 0, 0);

    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 6);
    endOfWeek.setHours(23, 59, 59, 999);

    let hasAnyPauseData = false;

    studyRecords.forEach(r => {
        const recordDate = new Date(r.date);
        const mtKey = mainTaskShortNameMappings[r.mainTask] || r.mainTask;
        const stKey = subTaskShortNameMappings[r.subTask] || r.subTask;
        const combinedKey = `${mtKey} - ${stKey}`;

        const pauses = r.pauseCount || 0;
        
        if (!pauseSummary[combinedKey]) {
            pauseSummary[combinedKey] = { dailyPauses: 0, weeklyPauses: 0 };
        }
        
        if (pauses > 0) { 
            hasAnyPauseData = true;
            const recordDayStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), recordDate.getDate());
            if (recordDayStart.getTime() === todayStart.getTime()) {
                 pauseSummary[combinedKey].dailyPauses += pauses;
            }
            if (recordDate >= startOfWeek && recordDate <= endOfWeek) {
                 pauseSummary[combinedKey].weeklyPauses += pauses;
            }
        }
    });


    if (!hasAnyPauseData && Object.keys(pauseSummary).every(k => pauseSummary[k].dailyPauses === 0 && pauseSummary[k].weeklyPauses === 0)) {
        reportContent.innerHTML = '<p>Hiçbir görev için duraklatma kaydı bulunmamaktadır.</p>';
        reportContent.style.display = 'block';
        return;
    }
    
    let html = `<table class="stat-table">
                    <thead>
                        <tr>
                            <th>Ana İş - Alt İş</th>
                            <th>Bugünkü Duraklatma Sayısı</th>
                            <th>Bu Haftaki Duraklatma Sayısı</th>
                        </tr>
                    </thead>
                    <tbody>`;

    const sortedKeys = Object.keys(pauseSummary).sort();
    let rowCount = 0;
    for (const key of sortedKeys) {
        if (pauseSummary[key].dailyPauses > 0 || pauseSummary[key].weeklyPauses > 0) {
            html += `<tr>
                        <td>${key}</td>
                        <td>${pauseSummary[key].dailyPauses}</td>
                        <td>${pauseSummary[key].weeklyPauses}</td>
                    </tr>`;
            rowCount++;
        }
    }
    html += '</tbody></table>';

    if (rowCount === 0) { 
         reportContent.innerHTML = '<p>Hiçbir görev için duraklatma kaydı bulunmamaktadır.</p>';
    } else {
        reportContent.innerHTML = html;
    }
    reportContent.style.display = 'block';
}

function displayDistractionAnalysisReport() {
    reportContent.innerHTML = '';
    chartsWrapper.style.display = 'none';
    aiChatContainer.style.display = 'none';
    productivityUpdateContent.style.display = 'none';
    if (productivityUpdateLoading) productivityUpdateLoading.style.display = 'none';

    const distractionSummary: { [combinedKey: string]: number } = {};
    let hasAnyDistractionData = false;

    studyRecords.forEach(r => {
        if (r.distractionCount && r.distractionCount > 0) {
            hasAnyDistractionData = true;
            const mtKey = mainTaskShortNameMappings[r.mainTask] || r.mainTask;
            const stKey = subTaskShortNameMappings[r.subTask] || r.subTask;
            const combinedKey = `${mtKey} - ${stKey}`;

            if (!distractionSummary[combinedKey]) {
                distractionSummary[combinedKey] = 0;
            }
            distractionSummary[combinedKey] += r.distractionCount;
        }
    });

    if (!hasAnyDistractionData) {
        reportContent.innerHTML = '<p>Hiçbir görev için dikkat dağınıklığı kaydı bulunmamaktadır.</p>';
        reportContent.style.display = 'block';
        return;
    }

    let html = `<table class="stat-table">
                    <thead>
                        <tr>
                            <th>Ana İş - Alt İş</th>
                            <th>Toplam Dikkat Dağınıklığı Sayısı</th>
                        </tr>
                    </thead>
                    <tbody>`;
    const sortedKeys = Object.keys(distractionSummary).sort((a, b) => distractionSummary[b] - distractionSummary[a]);
    for (const key of sortedKeys) {
        html += `<tr>
                    <td>${key}</td>
                    <td>${distractionSummary[key]}</td>
                </tr>`;
    }
    html += '</tbody></table>';
    reportContent.innerHTML = html;
    reportContent.style.display = 'block';
}


function closeModalGeneric(modalElement: HTMLElement) {
  modalElement.style.display = 'none';
  modalElement.setAttribute('aria-hidden', 'true');
}

closeModalBtn.addEventListener('click', () => closeModalGeneric(reportModal));
const settingsModalCloseButtons = settingsModal.querySelectorAll('.close');
settingsModalCloseButtons.forEach(btn => { (btn as HTMLButtonElement).addEventListener('click', () => closeModalGeneric(settingsModal)); });
if(closeGoalsModalBtn) closeGoalsModalBtn.addEventListener('click', () => closeModalGeneric(goalsModal));
if(closeEditSubTasksModalBtn) closeEditSubTasksModalBtn.addEventListener('click', () => closeModalGeneric(editSubTasksModal));


window.addEventListener('click', (event: MouseEvent) => {
  if (event.target === reportModal) closeModalGeneric(reportModal);
  if (event.target === settingsModal) closeModalGeneric(settingsModal);
  if (event.target === goalsModal) closeModalGeneric(goalsModal);
  if (event.target === editSubTasksModal) closeModalGeneric(editSubTasksModal);
});
window.addEventListener('keydown', (event: KeyboardEvent) => {
    if (event.key === 'Escape') {
        if (reportModal.style.display === 'block') closeModalGeneric(reportModal);
        if (settingsModal.style.display === 'block') closeModalGeneric(settingsModal);
        if (goalsModal.style.display === 'block') closeModalGeneric(goalsModal);
        if (editSubTasksModal.style.display === 'block') closeModalGeneric(editSubTasksModal);
        if (document.fullscreenElement) document.exitFullscreen().catch(e => console.error("Error exiting fullscreen with Esc:", e));
    }
});

settingsBtn.addEventListener('click', () => {
  pomodoroInput.value = pomodoroDuration.toString();
  themeSelect.value = selectedTheme;
  soundCheckbox.checked = soundEnabled;
  soundSelect.value = selectedSound;
  shortBreakDurationInput.value = shortBreakDurationMinutes.toString();
  longBreakDurationInput.value = longBreakDurationMinutes.toString();
  pomodorosPerLongBreakInput.value = pomodorosPerLongBreak.toString();
  populateMainTaskListUI();
  settingsModal.style.display = 'block';
  settingsModal.setAttribute('aria-hidden', 'false');
  pomodoroInput.focus();
});

saveSettingsBtn.addEventListener('click', () => {
  const newDuration = parseInt(pomodoroInput.value);
  const newShortBreak = parseInt(shortBreakDurationInput.value);
  const newLongBreak = parseInt(longBreakDurationInput.value);
  const newPomsPerLong = parseInt(pomodorosPerLongBreakInput.value);

  if (isNaN(newDuration) || newDuration < 1 || newDuration > 120) { alert("Lütfen Pomodoro süresi için 1 ile 120 arasında geçerli bir süre girin."); return; }
  if (isNaN(newShortBreak) || newShortBreak < 1 || newShortBreak > 30) { alert("Lütfen Kısa Mola için 1 ile 30 arasında geçerli bir süre girin."); return; }
  if (isNaN(newLongBreak) || newLongBreak < 5 || newLongBreak > 60) { alert("Lütfen Uzun Mola için 5 ile 60 arasında geçerli bir süre girin."); return; }
  if (isNaN(newPomsPerLong) || newPomsPerLong < 1 || newPomsPerLong > 10) { alert("Lütfen Uzun Mola Döngüsü için 1 ile 10 arasında geçerli bir sayı girin."); return; }
  
  const oldPomodoroDuration = pomodoroDuration;
  pomodoroDuration = newDuration;
  shortBreakDurationMinutes = newShortBreak;
  longBreakDurationMinutes = newLongBreak;
  pomodorosPerLongBreak = newPomsPerLong;
  
  selectedTheme = themeSelect.value;
  soundEnabled = soundCheckbox.checked;
  selectedSound = soundSelect.value;
  applyTheme();
  
  if (pomodoroState === 'idle' || pomodoroState === 'paused' ) {
    if (timeLeft === oldPomodoroDuration * 60 || pomodoroState === 'idle') { // If it was full or idle, reset to new duration
        timeLeft = pomodoroDuration * 60;
    }
    // If paused mid-session, and duration changed, it's debatable. For simplicity, current session continues with old duration.
    // Next session will pick up the new pomodoroDuration. However, if it's idle, always update.
    // Let's update timeLeft if idle, to reflect new duration immediately.
    if (pomodoroState === 'idle') {
        updateButtonVisibilityAndState(); // This will call updateTimerLabel
    }
  }
  // If running or break_proposed/break_running, new durations apply to next cycle.

  saveSettingsToLocalStorage();
  closeModalGeneric(settingsModal);
});

function applyTheme() {
    document.body.className = '';
    if (selectedTheme !== 'default') document.body.classList.add('theme-' + selectedTheme);
    updateChartFontColors();
}

function playBeep(soundType: string = selectedSound) {
  try {
    const AudioContextGlobal = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextGlobal) { console.warn("AudioContext API not supported. Beep disabled."); return; }
    const ctx = new AudioContextGlobal();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.1, ctx.currentTime); 

    switch (soundType) {
      case 'high_pitch':
        o.type = 'sine';
        o.frequency.setValueAtTime(1200, ctx.currentTime);
        break;
      case 'low_pitch': // Often good for break end
        o.type = 'triangle';
        o.frequency.setValueAtTime(440, ctx.currentTime);
        break;
      case 'short_pulse': // Good for alerts or early end
        o.type = 'square';
        o.frequency.setValueAtTime(1000, ctx.currentTime);
        break;
      case 'default': // Pomodoro end / general
      default:
        o.type = 'sine';
        o.frequency.setValueAtTime(880, ctx.currentTime);
        break;
    }

    o.connect(g);
    g.connect(ctx.destination);
    o.start();
    setTimeout(() => {
      o.stop();
      ctx.close().catch(e => console.error("Error closing AudioContext:", e));
    }, 300);
  } catch (e) { console.error("Could not play beep sound:", e); }
}

finishNowBtn.addEventListener('click', () => {
  if (pomodoroState !== 'running' && pomodoroState !== 'paused') {
      alert("Yalnızca aktif bir Pomodoro seansı hemen bitirilebilir.");
      return;
  }
  if (!selectedMainTask || !selectedSubTask) {
    alert('Lütfen önce Ana İş ve Alt İş seçin!');
    return;
  }
  
  if (timeLeft === pomodoroDuration * 60 && pomodoroState !== 'running') { // Check if timer hasn't effectively started for this session
      alert("Zamanlayıcı başlatılmamış veya zaten sıfırlanmış. Kaydedilecek bir süre yok.");
      return;
  }

  const secondsWorked = (pomodoroDuration * 60) - timeLeft;

  if (secondsWorked > 0) {
    addStudyTime(selectedMainTask, selectedSubTask, secondsWorked, currentPauseCount, currentDistractionCount);
  }

  if(pomodoroTimerId) clearInterval(pomodoroTimerId);
  pomodoroTimerId = null;
  timeLeft = pomodoroDuration * 60;
  currentPauseCount = 0; 
  currentDistractionCount = 0;
  
  pomodoroState = 'idle'; // Go to idle after finishing
  if (document.fullscreenElement) {
    document.exitFullscreen().catch(e => console.error("Error exiting fullscreen on finish now:", e));
  }
  updateButtonVisibilityAndState();
});

fullscreenBtn.addEventListener('click', () => {
    if (!document.fullscreenElement) {
        timerFocusArea.requestFullscreen().catch(err => alert(`Tam ekran modu etkinleştirilemedi: ${err.message} (${err.name})`));
    } else {
        document.exitFullscreen().catch(e => console.error("Error exiting fullscreen:", e));
    }
});
document.addEventListener('fullscreenchange', () => {
    const isInFullscreen = !!document.fullscreenElement;
    document.body.classList.toggle('timer-fullscreen-active', isInFullscreen);
    
    if (fullscreenBtn.style.display !== 'none') { // Only update if button is meant to be visible
        fullscreenBtn.textContent = isInFullscreen ? 'Çıkış' : 'Tam Ekran';
        fullscreenBtn.setAttribute('aria-label', isInFullscreen ? 'Tam Ekran Modundan Çık' : 'Tam Ekran Moduna Geç');
    }
    
    // If exiting fullscreen and timer/break is not running or proposed, hide button
    if (!isInFullscreen && pomodoroState !== 'running' && pomodoroState !== 'paused' && pomodoroState !== 'break_running') {
        fullscreenBtn.style.display = 'none';
    } else if (pomodoroState === 'running' || pomodoroState === 'paused' || pomodoroState === 'break_running') {
        fullscreenBtn.style.display = 'inline-block'; // Ensure it's visible if state allows
    }
});


function saveRecordsToLocalStorage() { try { localStorage.setItem('studyRecords', JSON.stringify(studyRecords)); } catch (e) { console.error("LS Save Records Error:", e); } }
function loadRecordsFromLocalStorage() { 
    try { 
        const r = localStorage.getItem('studyRecords'); 
        if (r) {
            const parsedRecords = JSON.parse(r) as StudyRecord[];
            studyRecords = parsedRecords.map(record => ({
                ...record,
                pauseCount: record.pauseCount === undefined ? 0 : record.pauseCount,
                distractionCount: record.distractionCount === undefined ? 0 : record.distractionCount
            }));
        }
    } catch (e) { 
        console.error("LS Load Records Error:", e); 
        studyRecords = []; 
    } 
}
interface PomodoroSettings { 
    pomodoroDuration: number; 
    selectedTheme: string; 
    soundEnabled: boolean; 
    selectedSound: string; 
    shortBreakDurationMinutes: number;
    longBreakDurationMinutes: number;
    pomodorosPerLongBreak: number;
    pomodoroCycleCounter: number;
}
function saveSettingsToLocalStorage() { 
    try { 
        const s: PomodoroSettings = { 
            pomodoroDuration, selectedTheme, soundEnabled, selectedSound,
            shortBreakDurationMinutes, longBreakDurationMinutes, pomodorosPerLongBreak,
            pomodoroCycleCounter
        }; 
        localStorage.setItem('pomodoroSettings', JSON.stringify(s)); 
    } catch (e) { 
        console.error("LS Save Settings Error:", e); 
    } 
}
function loadSettingsFromLocalStorage() {
    try {
        const s = localStorage.getItem('pomodoroSettings');
        if (s) { 
            const ps: PomodoroSettings = JSON.parse(s); 
            pomodoroDuration = ps.pomodoroDuration || 25; 
            selectedTheme = ps.selectedTheme || 'black'; // Default to black if not in saved settings
            soundEnabled = typeof ps.soundEnabled === 'boolean' ? ps.soundEnabled : true; 
            selectedSound = ps.selectedSound || 'default';
            shortBreakDurationMinutes = ps.shortBreakDurationMinutes || 5;
            longBreakDurationMinutes = ps.longBreakDurationMinutes || 15;
            pomodorosPerLongBreak = ps.pomodorosPerLongBreak || 4;
            pomodoroCycleCounter = ps.pomodoroCycleCounter || 0;
        } else {
            // No settings found, ensure all defaults are applied (selectedTheme is already 'black' by declaration)
            pomodoroDuration = 25;
            selectedTheme = 'black'; // Explicitly ensure black for robustness
            soundEnabled = true;
            selectedSound = 'default';
            shortBreakDurationMinutes = 5;
            longBreakDurationMinutes = 15;
            pomodorosPerLongBreak = 4;
            pomodoroCycleCounter = 0;
        }
    } catch (e) { 
        console.error("LS Load Settings Error:", e); 
        // Apply defaults on error
        pomodoroDuration = 25;
        selectedTheme = 'black';
        soundEnabled = true;
        selectedSound = 'default';
        shortBreakDurationMinutes = 5;
        longBreakDurationMinutes = 15;
        pomodorosPerLongBreak = 4;
        pomodoroCycleCounter = 0;
    }
}
function saveGoalsToLocalStorage() { try { localStorage.setItem('pomodoroGoals', JSON.stringify(goals)); } catch (e) { console.error("LS Save Goals Error:", e); } }
function loadGoalsFromLocalStorage() { try { const g = localStorage.getItem('pomodoroGoals'); if (g) goals = JSON.parse(g); } catch (e) { console.error("LS Load Goals Error:", e); goals = {}; } }
function saveSubTasksToLocalStorage() { try { localStorage.setItem('subTasksByMainTaskDefinition', JSON.stringify(subTasksByMainTaskDefinition)); } catch (e) { console.error("LS Save Main Tasks Error:", e); }}
function loadSubTasksFromLocalStorage() { try { const s = localStorage.getItem('subTasksByMainTaskDefinition'); if (s) subTasksByMainTaskDefinition = JSON.parse(s); } catch (e) { console.error("LS Load Main Tasks Error:", e); /* Keep default if error */ }}

function populateMainTaskListUI() {
    mainTaskListContainer.innerHTML = '';
    const taskNames = Object.keys(subTasksByMainTaskDefinition);
    if (taskNames.length === 0) {
        mainTaskListContainer.innerHTML = '<p>Henüz ana iş tanımlanmamış.</p>';
        return;
    }
    taskNames.forEach(taskName => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'main-task-item';
        const nameSpan = document.createElement('span');
        nameSpan.textContent = taskName;
        const deleteBtn = document.createElement('button');
        deleteBtn.className = 'delete-main-task-btn';
        deleteBtn.textContent = 'Sil';
        deleteBtn.setAttribute('aria-label', `${taskName} ana işini sil`);
        deleteBtn.dataset.taskName = taskName;
        deleteBtn.addEventListener('click', handleDeleteMainTask);
        itemDiv.appendChild(nameSpan);
        itemDiv.appendChild(deleteBtn);
        mainTaskListContainer.appendChild(itemDiv);
    });
}

function handleDeleteMainTask(event: MouseEvent) {
    const target = event.target as HTMLButtonElement;
    const taskNameToDelete = target.dataset.taskName;
    if (!taskNameToDelete) {
        return;
    }

    if (confirm(`"${taskNameToDelete}" ana işini ve tüm alt işlerini silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.`)) {
        delete subTasksByMainTaskDefinition[taskNameToDelete];

        if (goals[taskNameToDelete]) {
            delete goals[taskNameToDelete];
            saveGoalsToLocalStorage();
        }

        studyRecords = studyRecords.filter(record => record.mainTask !== taskNameToDelete);
        saveRecordsToLocalStorage();

        saveSubTasksToLocalStorage();
        populateMainTaskListUI(); 
        populateMainTaskDropdown(); 

        if (selectedMainTask === taskNameToDelete) {
            selectedMainTask = '';
            selectedSubTask = '';
            mainTaskSelect.value = '';
            subTaskSelect.value = '';
            populateSubTaskDropdown();
            editSubTasksBtn.style.display = 'none';
        }
        if (goalsModal.style.display === 'block') {
            populateGoalsFormContainerUI(); 
        }
    }
}

addMainTaskBtn.addEventListener('click', () => {
    const newMainTaskName = newMainTaskInput.value.trim();
    if (!newMainTaskName) {
        alert("Ana İş adı boş olamaz.");
        return;
    }
    if (subTasksByMainTaskDefinition[newMainTaskName]) {
        alert(`"${newMainTaskName}" adında bir Ana İş zaten mevcut.`);
        return;
    }
    subTasksByMainTaskDefinition[newMainTaskName] = [];
    saveSubTasksToLocalStorage();
    populateMainTaskListUI();
    populateMainTaskDropdown();
    newMainTaskInput.value = '';
    newMainTaskInput.focus();
});

editSubTasksBtn.addEventListener('click', () => {
    if (!selectedMainTask) {
        alert("Lütfen önce bir Ana İş seçin.");
        return;
    }
    editSubTasksModalTitle.textContent = `"${selectedMainTask}" için Alt İşler`;
    populateEditSubTasksModalUI();
    editSubTasksModal.style.display = 'block';
    editSubTasksModal.setAttribute('aria-hidden', 'false');
    newSubTaskNameModalInput.focus();
});

function populateEditSubTasksModalUI() {
    currentSubTaskListContainer.innerHTML = '';
    const subTasks = subTasksByMainTaskDefinition[selectedMainTask] || [];

    if (subTasks.length === 0) {
        currentSubTaskListContainer.innerHTML = '<p>Bu ana iş için henüz alt iş tanımlanmamış.</p>';
    } else {
        const ul = document.createElement('ul');
        ul.className = 'sub-task-list-modal';
        subTasks.forEach(subTask => {
            const li = document.createElement('li');
            li.className = 'sub-task-item-modal';
            const nameSpan = document.createElement('span');
            nameSpan.textContent = subTask;
            const deleteBtn = document.createElement('button');
            deleteBtn.className = 'delete-sub-task-btn-modal';
            deleteBtn.textContent = 'Sil';
            deleteBtn.setAttribute('aria-label', `${subTask} alt işini sil`);
            deleteBtn.dataset.subTaskName = subTask;
            deleteBtn.addEventListener('click', handleDeleteSubTaskFromModal);
            li.appendChild(nameSpan);
            li.appendChild(deleteBtn);
            ul.appendChild(li);
        });
        currentSubTaskListContainer.appendChild(ul);
    }
}

function handleDeleteSubTaskFromModal(event: MouseEvent) {
    const target = event.target as HTMLButtonElement;
    const subTaskNameToDelete = target.dataset.subTaskName;

    if (!subTaskNameToDelete || !selectedMainTask || !subTasksByMainTaskDefinition[selectedMainTask]) {
        return;
    }
    if (confirm(`"${selectedMainTask}" ana işinden "${subTaskNameToDelete}" alt işini silmek istediğinizden emin misiniz?`)) {
        const currentSubTasks = subTasksByMainTaskDefinition[selectedMainTask];
        subTasksByMainTaskDefinition[selectedMainTask] = currentSubTasks.filter(st => st !== subTaskNameToDelete);
        
        studyRecords = studyRecords.filter(record => !(record.mainTask === selectedMainTask && record.subTask === subTaskNameToDelete));
        saveRecordsToLocalStorage();

        saveSubTasksToLocalStorage();
        populateEditSubTasksModalUI(); 
        populateSubTaskDropdown(); 

        if (selectedSubTask === subTaskNameToDelete) {
            selectedSubTask = '';
            subTaskSelect.value = '';
        }
    }
}

addSubTaskModalBtn.addEventListener('click', () => {
    if (!selectedMainTask) return;

    const newSubTaskName = newSubTaskNameModalInput.value.trim();
    if (!newSubTaskName) {
        alert("Alt İş adı boş olamaz.");
        return;
    }
    const currentSubTasks = subTasksByMainTaskDefinition[selectedMainTask] || [];
    if (currentSubTasks.includes(newSubTaskName)) {
        alert(`"${newSubTaskName}" adında bir Alt İş zaten "${selectedMainTask}" altında mevcut.`);
        return;
    }
    subTasksByMainTaskDefinition[selectedMainTask].push(newSubTaskName);
    saveSubTasksToLocalStorage();
    populateEditSubTasksModalUI();
    populateSubTaskDropdown(); 
    subTaskSelect.value = newSubTaskName;
    selectedSubTask = newSubTaskName; 

    newSubTaskNameModalInput.value = '';
    newSubTaskNameModalInput.focus();
});

function populateGoalsFormContainerUI() {
    goalsFormContainer.innerHTML = '';
    const availableMainTasks = Object.keys(subTasksByMainTaskDefinition);
    if (availableMainTasks.length === 0) {
        goalsFormContainer.innerHTML = '<p>Lütfen önce "Ayarlar" bölümünden bir Ana İş ekleyin.</p>';
    } else {
        availableMainTasks.forEach(mainTask => {
            const mainTaskGoal = goals[mainTask] || { weeklyGoal: 0, monthlyGoal: 0 };
            const groupDiv = document.createElement('div');
            groupDiv.className = 'goal-main-task-group';

            const nameEl = document.createElement('div');
            nameEl.className = 'goal-main-task-name';
            nameEl.textContent = mainTask;
            groupDiv.appendChild(nameEl);

            ['weekly', 'monthly'].forEach(period => {
                const periodGoal = period === 'weekly' ? mainTaskGoal.weeklyGoal : mainTaskGoal.monthlyGoal;
                const periodText = period === 'weekly' ? 'Haftalık' : 'Aylık';
                const inputGroup = document.createElement('div');
                inputGroup.className = 'goal-input-group';
                const label = document.createElement('label');
                label.htmlFor = `goal-${period}-${mainTask}`;
                label.textContent = `${periodText} Hedef (dk):`;
                const input = document.createElement('input');
                input.type = 'number';
                input.id = `goal-${period}-${mainTask}`;
                input.name = `goal-${period}-${mainTask}`;
                input.min = "0";
                input.value = periodGoal.toString();
                input.setAttribute('aria-label', `${mainTask} ${periodText} Hedef Dakika`);
                inputGroup.appendChild(label);
                inputGroup.appendChild(input);
                groupDiv.appendChild(inputGroup);
            });
            goalsFormContainer.appendChild(groupDiv);
        });
    }
}

goalsSettingsBtn.addEventListener('click', () => {
    populateGoalsFormContainerUI();
    goalsModal.style.display = 'block';
    goalsModal.setAttribute('aria-hidden', 'false');
    const firstInput = goalsFormContainer.querySelector('input[type="number"]') as HTMLInputElement | null;
    if (firstInput) firstInput.focus();
});

saveGoalsBtn.addEventListener('click', () => {
    const newGoals: PomodoroGoals = {};
    Object.keys(subTasksByMainTaskDefinition).forEach(mainTask => {
        const weeklyInput = document.getElementById(`goal-weekly-${mainTask}`) as HTMLInputElement;
        const monthlyInput = document.getElementById(`goal-monthly-${mainTask}`) as HTMLInputElement;
        const weeklyGoal = weeklyInput ? parseInt(weeklyInput.value) || 0 : 0;
        const monthlyGoal = monthlyInput ? parseInt(monthlyInput.value) || 0 : 0;
        if (weeklyGoal >= 0 || monthlyGoal >= 0) { 
            newGoals[mainTask] = { weeklyGoal, monthlyGoal };
        }
    });
    goals = newGoals;
    saveGoalsToLocalStorage();
    closeModalGeneric(goalsModal);
});

function getCurrentWeekDateRange(): { start: Date, end: Date } {
    const now = new Date(); const today = now.getDay(); const diffToMonday = today === 0 ? -6 : 1 - today; 
    const startOfWeek = new Date(now.getFullYear(), now.getMonth(), now.getDate() + diffToMonday);
    startOfWeek.setHours(0, 0, 0, 0);
    const endOfWeek = new Date(startOfWeek); endOfWeek.setDate(startOfWeek.getDate() + 6); endOfWeek.setHours(23, 59, 59, 999);
    return { start: startOfWeek, end: endOfWeek };
}
function getCurrentMonthDateRange(): { start: Date, end: Date } {
    const now = new Date(); const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1); startOfMonth.setHours(0,0,0,0);
    const endOfMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0); endOfMonth.setHours(23,59,59,999);
    return { start: startOfMonth, end: endOfMonth };
}

function displayGoalProgressReport() {
    reportContent.innerHTML = ''; 
    chartsWrapper.style.display = 'none';
    aiChatContainer.style.display = 'none';
    productivityUpdateContent.style.display = 'none';

    let contentHtml = '';
    const relevantGoalKeys = Object.keys(goals).filter(mainTask => subTasksByMainTaskDefinition[mainTask]);


    if (relevantGoalKeys.length === 0) {
        reportContent.innerHTML = '<p>Henüz bir hedef belirlemediniz veya hedefleriniz mevcut olmayan ana işlere atanmış. Lütfen "Hedef Ayarları" ve "Ayarlar" bölümlerini kontrol edin.</p>';
    } else {
        const weeklyRange = getCurrentWeekDateRange(); const monthlyRange = getCurrentMonthDateRange();
        relevantGoalKeys.forEach(mainTask => {
            const mainTaskGoals = goals[mainTask]; 
            let weeklyStudiedSeconds = 0; let monthlyStudiedSeconds = 0;
            studyRecords.forEach(record => {
                if (record.mainTask === mainTask) {
                    const recordDate = new Date(record.date);
                    if (recordDate >= weeklyRange.start && recordDate <= weeklyRange.end) weeklyStudiedSeconds += record.seconds;
                    if (recordDate >= monthlyRange.start && recordDate <= monthlyRange.end) monthlyStudiedSeconds += record.seconds;
                }
            });
            const weeklyStudiedMinutes = Math.round(weeklyStudiedSeconds / 60);
            const monthlyStudiedMinutes = Math.round(monthlyStudiedSeconds / 60);

            contentHtml += `<div class="goal-progress-item" aria-labelledby="goal-title-${mainTask}">`;
            contentHtml += `<h3 id="goal-title-${mainTask}" class="goal-main-task-title">${mainTask} Hedefleri</h3>`;
            if (mainTaskGoals.weeklyGoal > 0) {
                const weeklyPercentage = Math.min(100, mainTaskGoals.weeklyGoal === 0 ? 0 : Math.round((weeklyStudiedMinutes / mainTaskGoals.weeklyGoal) * 100));
                contentHtml += `<div class="progress-bar-label" id="weekly-label-${mainTask}">Haftalık: ${weeklyStudiedMinutes} / ${mainTaskGoals.weeklyGoal} dk</div>
                                <div class="progress-bar-container" role="progressbar" aria-valuenow="${weeklyStudiedMinutes}" aria-valuemin="0" aria-valuemax="${mainTaskGoals.weeklyGoal}" aria-labelledby="weekly-label-${mainTask}">
                                    <div class="progress-bar ${weeklyPercentage === 100 ? 'full' : ''}" style="width: ${weeklyPercentage}%;"><span class="progress-bar-text">${weeklyPercentage}%</span></div></div>`;
            } else contentHtml += `<p class="progress-bar-label">Haftalık hedef belirlenmemiş.</p>`;
            if (mainTaskGoals.monthlyGoal > 0) {
                const monthlyPercentage = Math.min(100, mainTaskGoals.monthlyGoal === 0 ? 0 : Math.round((monthlyStudiedMinutes / mainTaskGoals.monthlyGoal) * 100));
                contentHtml += `<div class="progress-bar-label" id="monthly-label-${mainTask}" style="margin-top: 0.75rem;">Aylık: ${monthlyStudiedMinutes} / ${mainTaskGoals.monthlyGoal} dk</div>
                                <div class="progress-bar-container" role="progressbar" aria-valuenow="${monthlyStudiedMinutes}" aria-valuemin="0" aria-valuemax="${mainTaskGoals.monthlyGoal}" aria-labelledby="monthly-label-${mainTask}">
                                    <div class="progress-bar ${monthlyPercentage === 100 ? 'full' : ''}" style="width: ${monthlyPercentage}%;"><span class="progress-bar-text">${monthlyPercentage}%</span></div></div>`;
            } else contentHtml += `<p class="progress-bar-label" style="margin-top: 0.75rem;">Aylık hedef belirlenmemiş.</p>`;
            contentHtml += `</div>`;
        });
        if(contentHtml === '') reportContent.innerHTML = '<p>Gösterilecek aktif hedef bulunmamaktadır. Lütfen hedeflerinizi kontrol edin.</p>';
        else reportContent.innerHTML = contentHtml;
    }
    reportContent.style.display = 'block'; 
}

// --- AI Chat Functions ---
function addMessageToChat(role: 'user' | 'model' | 'error', text: string) {
    chatHistory.push({ role, text });
    renderChatMessages();
}

function renderChatMessages() {
    chatMessagesDiv.innerHTML = '';
    chatHistory.forEach(msg => {
        const messageEl = document.createElement('div');
        messageEl.classList.add('message', `${msg.role}-message`);
        if (msg.role === 'model') {
            messageEl.innerHTML = msg.text.replace(/\n/g, '<br>');
        } else {
            messageEl.textContent = msg.text;
        }
        chatMessagesDiv.appendChild(messageEl);
    });
    chatMessagesDiv.scrollTop = chatMessagesDiv.scrollHeight;
}

function prepareStudyDataForAI(filterDays?: number): string {
    let dataString: string;
    let relevantRecords = studyRecords;
    const currentDate = new Date(); 

    if (filterDays && filterDays > 0) {
        const startDate = new Date(currentDate); 
        startDate.setDate(startDate.getDate() - filterDays);
        relevantRecords = studyRecords.filter(r => new Date(r.date) >= startDate);
        dataString = `Kullanıcının Son ${filterDays} Günlük Çalışma Kayıtları (Bugün: ${currentDate.toLocaleDateString('tr-TR')}):\n`;
    } else {
        dataString = `Kullanıcının Tüm Çalışma Kayıtları (Bugün: ${currentDate.toLocaleDateString('tr-TR')}):\n`;
    }

    if (relevantRecords.length === 0) {
        dataString += "Hiç çalışma kaydı bulunmamaktadır.\n";
    } else {
        relevantRecords.forEach(record => {
            const date = new Date(record.date).toLocaleDateString('tr-TR', { weekday: 'short', year: 'numeric', month: 'short', day: 'numeric' });
            const duration = Math.round(record.seconds / 60);
            dataString += `- Ana İş: ${record.mainTask}, Alt İş: ${record.subTask}, Süre: ${duration} dakika, Duraklatma Sayısı: ${record.pauseCount ?? 0}, Dikkat Dağılıklığı Sayısı: ${record.distractionCount ?? 0}, Tarih: ${date}\n`;
        });
    }

    dataString += "\nKullanıcının Hedefleri:\n";
    if (Object.keys(goals).length === 0) {
        dataString += "Belirlenmiş bir hedef bulunmamaktadır.\n";
    } else {
        for (const mainTask in goals) {
            if (subTasksByMainTaskDefinition[mainTask]) { 
                 dataString += `- Ana İş: ${mainTask}, Haftalık Hedef: ${goals[mainTask].weeklyGoal} dk, Aylık Hedef: ${goals[mainTask].monthlyGoal} dk\n`;
            }
        }
    }
    return dataString;
}

async function handleSendChatMessage() {
    const userQuestion = chatInput.value.trim();
    if (!userQuestion || isAIChatLoading || !ai) return;

    addMessageToChat('user', userQuestion);
    chatInput.value = '';
    isAIChatLoading = true;
    chatLoading.style.display = 'block';
    sendChatBtn.disabled = true;
    chatInput.disabled = true;

    const studyData = prepareStudyDataForAI(); 
    const prompt = `Sen bir Pomodoro çalışma uygulaması için yardımsever bir veri analiz asistanısın. Kullanıcının çalışma kayıtları ve hedefleri aşağıda yapılandırılmış bir formatta sunulmuştur. Senin görevin, yalnızca bu sağlanan verilere dayanarak kullanıcının sorularını doğru, kısa ve öz bir şekilde Türkçe yanıtlamaktır. Bilgi uydurma. Veriler bir soruyu yanıtlamak için yetersizse, bunu açıkça belirt. İstendiği gibi hesaplamalar, karşılaştırmalar ve özetler yap. Cevaplarını madde işaretleri veya kısa paragraflar halinde sunmaya çalış.

Çalışma Kayıtları Detayları: Her kayıt bir çalışma oturumunu temsil eder ve şunları içerir:
- Ana İş: Çalışılan ana konu veya ders.
- Alt İş: Ana işin belirli bir alt konusu.
- Süre: Oturum için kaydedilen net çalışma süresi (dakika cinsinden).
- Duraklatma Sayısı: O oturum sırasında zamanlayıcının kaç kez duraklatıldığı. Yüksek bir duraklatma sayısı, o görev sırasında daha az odaklanma veya daha fazla kesinti anlamına gelebilir. Düşük duraklatma sayısı daha iyi odaklanmayı gösterir.
- Dikkat Dağılıklığı Sayısı: O oturum sırasında kullanıcının kaç kez 'Dikkatim Dağıldı' butonuna tıkladığını gösterir. Yüksek bir sayı, o görev sırasında daha fazla içsel veya dışsal dikkat dağıtıcı faktörle karşılaşıldığını veya odaklanma zorluğu yaşandığını düşündürebilir. AI olarak bu sayıyı, kullanıcının hangi görevlerde daha fazla yardıma veya farklı stratejilere ihtiyaç duyabileceğini belirlemede bir gösterge olarak kullanabilirsin.
- Tarih: Çalışma kaydının yapıldığı tarih.
Hedefler şunları içerir: Her ana iş için haftalık ve aylık hedef dakikaları.

Akıllı Hedef Önerileri:
Kullanıcı hedef önerisi istediğinde ("hedef öner", "suggest goal", "bir hedef belirlememe yardımcı ol" gibi ifadelerle) veya belirli bir ders/görev için hedef istediğinde ("Matematik için hedef öner", "Fizik - Hareket için haftalık hedef" gibi), aşağıdaki adımları izle:
1.  Sağlanan çalışma kayıtlarını analiz et. Özellikle son 7-30 günlük verilere odaklanarak bir göreve ne kadar süre ayrıldığını ve ne sıklıkta çalışıldığını belirle.
2.  Kullanıcının mevcut hedeflerini kontrol et.
3.  Eğer belirli bir görev için hedef isteniyorsa ve o görev için yeterli veri varsa (örneğin, son bir ay içinde en az 2-3 kez çalışılmışsa ve toplamda en az 60-90 dakika harcanmışsa), gerçekçi bir haftalık veya aylık hedef (dakika cinsinden) öner. Önerini, gözlemlenen çalışma süresine dayandır. Örneğin: "'[Görev Adı]' için son bir haftada ortalama X dakika çalıştığınızı görüyorum. Haftalık Y dakika hedefi uygun olabilir."
4.  Eğer kullanıcı genel bir hedef önerisi istiyorsa, sık çalışılan ancak henüz hedefi olmayan görevler için veya mevcut hedeflerinden önemli ölçüde sapan (çok altında kalan veya çok üstüne çıkan) görevler için önerilerde bulun. "Şu anda '[Görev Adı]' için bir hedefiniz yok ve son zamanlarda sıkça çalışıyorsunuz. Haftalık X dakika hedeflemeye ne dersiniz?" veya "Mevcut '[Görev Adı]' haftalık hedefiniz X dakika, ancak ortalama Y dakika çalışıyorsunuz. Hedefinizi Y dakikaya güncellemek isteyebilirsiniz." şeklinde ifadeler kullan. Birden fazla öneri sunabilirsin.
5.  Bir görev için yeterli veri yoksa, bunu açıkça belirt. Örneğin: "'[Görev Adı]' için henüz yeterli çalışma verisi bulunmuyor. Bir hedef önerebilmem için bu göreve biraz daha zaman ayırmanızı öneririm."
6.  Önerilerini her zaman sağlanan verilere dayandır ve kısa, net ve eyleme geçirilebilir tut. Yanıtlarının başına "Hedef Önerisi:" gibi bir başlık ekleme, sadece doğal bir konuşma akışında cevap ver.

Veri:
${studyData}

Kullanıcının Sorusu: ${userQuestion}
Cevap:`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
        });
        addMessageToChat('model', response.text);
    } catch (error) {
        console.error("AI Chat Error:", error);
        let errorMessage = "AI ile iletişim kurulurken bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
        if (error instanceof Error && error.message.includes("API_KEY")) {
            errorMessage = "API anahtarınızla ilgili bir sorun var gibi görünüyor. Lütfen kontrol edin.";
        }
        addMessageToChat('error', errorMessage);
    } finally {
        isAIChatLoading = false;
        chatLoading.style.display = 'none';
        if(apiKey) { 
            sendChatBtn.disabled = false;
            chatInput.disabled = false;
            chatInput.focus();
        }
    }
}

function displayAIChatInterface() {
    reportContent.style.display = 'none';
    chartsWrapper.style.display = 'none';
    productivityUpdateContent.style.display = 'none';
    aiChatContainer.style.display = 'flex';

    if (!apiKey) {
        apiKeyMissingDiv.style.display = 'block';
        chatInput.disabled = true;
        sendChatBtn.disabled = true;
        if (chatHistory.length === 0 || chatHistory.every(m => m.role !== 'error' || !m.text.includes('API anahtarı'))) {
             addMessageToChat('error', 'AI Sohbet özelliği için API anahtarı yapılandırılmamış.');
        }
    } else {
        apiKeyMissingDiv.style.display = 'none';
        chatInput.disabled = false;
        sendChatBtn.disabled = false;
        if (ai === null) { 
            try {
                ai = new GoogleGenAI({ apiKey });
                if (chatHistory.length === 0) { 
                    addMessageToChat('model', 'Merhaba! Çalışma verileriniz hakkında ne merak ediyorsunuz? Örneğin, "En çok hangi derse çalıştım?", "Matematik dersinde ne kadar ilerledim?" veya "Bana bir hedef önerir misin?" gibi sorular sorabilirsiniz.');
                }
            } catch (e) {
                console.error("GoogleGenAI initialization error:", e);
                addMessageToChat('error', 'AI servisi başlatılamadı. API anahtarınız doğru mu veya bir ağ sorunu mu var?');
                apiKeyMissingDiv.textContent = 'AI servisi başlatılamadı. API anahtarınız doğru mu veya bir ağ sorunu mu var?';
                apiKeyMissingDiv.style.display = 'block';
                chatInput.disabled = true;
                sendChatBtn.disabled = true;
            }
        } else if (chatHistory.length === 0) { 
             addMessageToChat('model', 'Merhaba! Çalışma verileriniz hakkında ne merak ediyorsunuz? Bana hedef önermemi de isteyebilirsiniz.');
        }
    }
    renderChatMessages(); 
    chatInput.focus();
}

async function fetchAndDisplayProductivityUpdate() {
    if (!productivityUpdateContent || !productivityUpdateLoading) return;

    productivityUpdateContent.style.display = 'block';
    productivityUpdateLoading.style.display = 'block';
    reportContent.style.display = 'none';
    chartsWrapper.style.display = 'none';
    aiChatContainer.style.display = 'none';
    productivityUpdateContent.innerHTML = ''; 

    if (!apiKey) {
        productivityUpdateContent.innerHTML = '<p class="api-key-message">Verimlilik güncellemesi özelliği için API anahtarı yapılandırılmamış. Lütfen API anahtarınızı sağlayın.</p>';
        productivityUpdateLoading.style.display = 'none';
        return;
    }
    if (!ai) {
        try {
            ai = new GoogleGenAI({ apiKey });
        } catch (e) {
            console.error("GoogleGenAI initialization error for productivity update:", e);
            productivityUpdateContent.innerHTML = '<p class="error-message">AI servisi başlatılamadı. API anahtarınız doğru mu veya bir ağ sorunu mu var?</p>';
            productivityUpdateLoading.style.display = 'none';
            return;
        }
    }

    const studyData = prepareStudyDataForAI(7); 
    const prompt = `Sen bir verimlilik koçusun. Aşağıdaki son 7 günlük Türkçe çalışma verilerine dayanarak kısa bir verimlilik güncellemesi sağla. Şunları dahil et:
1.  Çalışma alışkanlıklarının genel bir özeti (örn: "Bu hafta düzenli çalıştın...", "Çalışmaların daha çok hafta sonu yoğunlaşmış...").
2.  Gözlemlenen bir temel güçlü yön (örn: "Matematik problem çözmede istikrarlı bir zaman ayırmışsın.", "Fizik kuvvet konusunda iyi odaklanmışsın.").
3.  Geliştirilebilecek bir temel alan (örn: "Kimya periyodik sistem konusuna daha fazla zaman ayırabilirsin.", "Tarih inkılaplar konusunda duraklama/dikkat dağınıklığı sayın biraz yüksek, odaklanmayı artırabilirsin.").
4.  Uygulanabilir bir verimlilik ipucu (örn: "Çalışma seanslarını daha kısa parçalara bölmeyi dene.", "Zorlandığın konular için farklı öğrenme teknikleri kullan.").
Tüm yanıtı 150 kelimenin altında tut ve Türkçe yaz. Çıktıyı net bir şekilde HTML olarak biçimlendir (paragraflar için <p>, başlıklar için <h4>, listeler için <ul> ve <li> etiketlerini kullan). Madde işaretlerini kullanırken (<ul><li>) her bir maddeyi ayrı bir <li> içine al.

Veri:
${studyData}

Güncelleme:`;

    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
        });
        
        let htmlResponse = response.text;
        const fenceRegex = /^```(?:html)?\s*\n?(.*?)\n?\s*```$/s;
        const match = htmlResponse.match(fenceRegex);
        if (match && match[1]) { 
            htmlResponse = match[1].trim(); 
        }
        productivityUpdateContent.innerHTML = htmlResponse;

    } catch (error) {
        console.error("AI Productivity Update Error:", error);
        let errorMessage = "Verimlilik güncellemesi alınırken bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
         if (error instanceof Error && error.message.includes("API_KEY")) {
            errorMessage = "API anahtarınızla ilgili bir sorun var gibi görünüyor. Lütfen kontrol edin.";
        }
        productivityUpdateContent.innerHTML = `<p class="error-message">${errorMessage}</p>`;
    } finally {
        productivityUpdateLoading.style.display = 'none';
    }
}


// --- End AI Chat Functions ---

document.addEventListener('DOMContentLoaded', () => {
    loadSettingsFromLocalStorage();
    loadSubTasksFromLocalStorage();
    loadRecordsFromLocalStorage();
    loadGoalsFromLocalStorage();

    pomodoroInput.value = pomodoroDuration.toString();
    themeSelect.value = selectedTheme;
    soundCheckbox.checked = soundEnabled;
    soundSelect.value = selectedSound;
    shortBreakDurationInput.value = shortBreakDurationMinutes.toString();
    longBreakDurationInput.value = longBreakDurationMinutes.toString();
    pomodorosPerLongBreakInput.value = pomodorosPerLongBreak.toString();
    
    timeLeft = pomodoroDuration * 60; 
    pomodoroState = 'idle'; // Initialize state

    applyTheme();
    populateMainTaskDropdown(); 

    const lastSelectedMainTask = localStorage.getItem('lastSelectedMainTask');
    const lastSelectedSubTask = localStorage.getItem('lastSelectedSubTask');

    if (lastSelectedMainTask && subTasksByMainTaskDefinition[lastSelectedMainTask]) {
        mainTaskSelect.value = lastSelectedMainTask;
        selectedMainTask = lastSelectedMainTask; 
        populateSubTaskDropdown(); 
        if (lastSelectedSubTask && subTasksByMainTaskDefinition[lastSelectedMainTask]?.includes(lastSelectedSubTask)) {
            subTaskSelect.value = lastSelectedSubTask;
            selectedSubTask = lastSelectedSubTask; 
        } else {
          subTaskSelect.value = ''; 
          selectedSubTask = '';
        }
    } else {
        mainTaskSelect.value = ''; 
        subTaskSelect.value = '';
        selectedMainTask = '';
        selectedSubTask = '';
        editSubTasksBtn.style.display = 'none';
        populateSubTaskDropdown(); 
    }
    
    updateButtonVisibilityAndState(); // Initial UI setup based on state
    if (typeof Chart !== 'undefined') updateChartFontColors();

    // AI Chat Event Listeners
    sendChatBtn.addEventListener('click', handleSendChatMessage);
    chatInput.addEventListener('keypress', (event) => {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            handleSendChatMessage();
        }
    });
});

mainTaskSelect.addEventListener('change', () => {
    localStorage.setItem('lastSelectedMainTask', mainTaskSelect.value);
    localStorage.removeItem('lastSelectedSubTask'); 
});
subTaskSelect.addEventListener('change', () => {
    if (subTaskSelect.value) {
        localStorage.setItem('lastSelectedSubTask', subTaskSelect.value);
    } else {
        localStorage.removeItem('lastSelectedSubTask');
    }
});


[startBtn, pauseBtn, resetBtn, reportBtn, settingsBtn, saveSettingsBtn, fullscreenBtn, finishNowBtn, goalsSettingsBtn, saveGoalsBtn, addMainTaskBtn, editSubTasksBtn, addSubTaskModalBtn, startBreakBtn, skipBreakBtn, endBreakBtn, distractionBtn].forEach(btn => {
    if (btn) btn.addEventListener('keydown', (event: KeyboardEvent) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); btn.click(); } });
});
[closeModalBtn, ...Array.from(settingsModal.querySelectorAll('.close')), closeGoalsModalBtn, closeEditSubTasksModalBtn].forEach(btn => {
     if (btn) (btn as HTMLButtonElement).addEventListener('keydown', (event: KeyboardEvent) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); (btn as HTMLButtonElement).click(); } });
});
filterBtns.forEach(btn => { (btn as HTMLButtonElement).addEventListener('keydown', (event: KeyboardEvent) => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); (btn as HTMLButtonElement).click(); } });
});
